#include "Player.h"

int main() {

	Player p1("Jim");
	Player p2;

	cout << "Well I'm here" << endl;

	return 0;

}
