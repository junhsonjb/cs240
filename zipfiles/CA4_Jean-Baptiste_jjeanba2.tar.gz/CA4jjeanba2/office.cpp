#include <iostream>
using namespace std; 

#include "LLC.h"

int main()
{
   LLC<string> one; 
   LLC<int> two; 

   cout << one << endl;
   cout << two << endl;

   cout << "Hello" << endl;
}




