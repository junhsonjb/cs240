#include "Node.h"

// Constructor
Node::Node(string newdata) {

	// initialize this node from the data given
	data = newdata;
	next = nullptr;
}
